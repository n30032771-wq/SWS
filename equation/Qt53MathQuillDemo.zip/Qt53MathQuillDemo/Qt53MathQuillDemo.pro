QT += core gui widgets webkit webkitwidgets network

TARGET = Qt53MathQuillDemo
TEMPLATE = app

SOURCES += \
    main.cpp \
    mainwindow.cpp

HEADERS += \
    mainwindow.h

RESOURCES += \
    resources.qrc
