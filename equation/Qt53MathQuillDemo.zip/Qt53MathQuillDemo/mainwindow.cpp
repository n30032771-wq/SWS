#include "mainwindow.h"

#include <QApplication>
#include <QClipboard>
#include <QGridLayout>
#include <QFont>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QSignalMapper>
#include <QUrl>
#include <QVariant>
#include <QVBoxLayout>
#include <QWidget>

#include <QtWebKit/QWebFrame>
#include <QtWebKitWidgets/QWebPage>
#include <QtWebKitWidgets/QWebView>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent),
      webView(new QWebView(this)),
      latexEdit(new QLineEdit(this)),
      statusLabel(new QLabel(this)),
      commandMapper(new QSignalMapper(this))
{
    setWindowTitle("Qt 5.3 MathQuill Equation Editor");
    resize(980, 620);

    QWidget *central = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(central);

    QLabel *title = new QLabel("Visual Equation Editor", central);
    QFont titleFont = title->font();
    titleFont.setPointSize(titleFont.pointSize() + 4);
    titleFont.setBold(true);
    title->setFont(titleFont);
    mainLayout->addWidget(title);

    QLabel *help = new QLabel(
        "Click a math button, or click inside the equation and type. "
        "Use the LaTeX box below to read or replace the whole equation.", central);
    help->setWordWrap(true);
    mainLayout->addWidget(help);

    QGridLayout *toolbar = new QGridLayout;

    struct ButtonDef {
        const char *caption;
        const char *command;
        const char *tooltip;
    };

    const ButtonDef buttons[] = {
        {"a/b", "\\frac", "Fraction"},
        {"sqrt", "\\sqrt", "Square root"},
        {"x^", "^", "Superscript / power"},
        {"x_", "_", "Subscript"},
        {"Integral", "\\int", "Integral"},
        {"Sum", "\\sum", "Summation"},
        {"lim", "\\lim", "Limit"},
        {"+/-", "\\pm", "Plus or minus"},
        {"x", "\\times", "Multiplication sign"},
        {"divide", "\\div", "Division sign"},
        {"infinity", "\\infty", "Infinity"},
        {"pi", "\\pi", "Pi"},
        {"alpha", "\\alpha", "Greek alpha"},
        {"beta", "\\beta", "Greek beta"},
        {"theta", "\\theta", "Greek theta"},
        {"<=", "\\le", "Less than or equal"},
        {">=", "\\ge", "Greater than or equal"},
        {"!=", "\\ne", "Not equal"},
        {"sin", "\\sin", "Sine"},
        {"cos", "\\cos", "Cosine"},
        {"log", "\\log", "Logarithm"}
    };

    const int buttonCount = sizeof(buttons) / sizeof(buttons[0]);
    const int columns = 7;
    for (int i = 0; i < buttonCount; ++i) {
        QPushButton *button = makeCommandButton(
            buttons[i].caption,
            buttons[i].command,
            buttons[i].tooltip);
        toolbar->addWidget(button, i / columns, i % columns);
    }

    mainLayout->addLayout(toolbar);

    webView->setMinimumHeight(300);
    webView->setContextMenuPolicy(Qt::DefaultContextMenu);
    mainLayout->addWidget(webView, 1);

    QHBoxLayout *latexLayout = new QHBoxLayout;
    QLabel *latexLabel = new QLabel("LaTeX:", central);
    latexEdit->setText("x=\\frac{-b+\\sqrt{b^2-4ac}}{2a}");

    QPushButton *getButton = new QPushButton("Get LaTeX", central);
    QPushButton *setButton = new QPushButton("Set LaTeX", central);
    QPushButton *copyButton = new QPushButton("Copy", central);
    QPushButton *clearButton = new QPushButton("Clear", central);

    latexLayout->addWidget(latexLabel);
    latexLayout->addWidget(latexEdit, 1);
    latexLayout->addWidget(getButton);
    latexLayout->addWidget(setButton);
    latexLayout->addWidget(copyButton);
    latexLayout->addWidget(clearButton);
    mainLayout->addLayout(latexLayout);

    statusLabel->setText("Loading MathQuill...");
    mainLayout->addWidget(statusLabel);

    setCentralWidget(central);

    connect(commandMapper, SIGNAL(mapped(QString)),
            this, SLOT(insertCommand(QString)));
    connect(getButton, SIGNAL(clicked()), this, SLOT(getLatex()));
    connect(setButton, SIGNAL(clicked()), this, SLOT(setLatex()));
    connect(copyButton, SIGNAL(clicked()), this, SLOT(copyLatex()));
    connect(clearButton, SIGNAL(clicked()), this, SLOT(clearEquation()));
    connect(webView, SIGNAL(loadFinished(bool)),
            this, SLOT(onLoadFinished(bool)));

    // editor.html is compiled into the executable with resources.qrc.
    webView->load(QUrl("qrc:/web/editor.html"));
}

MainWindow::~MainWindow()
{
}

QPushButton *MainWindow::makeCommandButton(const QString &caption,
                                           const QString &command,
                                           const QString &toolTip)
{
    QPushButton *button = new QPushButton(caption, this);
    button->setMinimumHeight(34);
    if (!toolTip.isEmpty())
        button->setToolTip(toolTip);

    connect(button, SIGNAL(clicked()), commandMapper, SLOT(map()));
    commandMapper->setMapping(button, command);
    return button;
}

QString MainWindow::quoteForJavaScript(const QString &text) const
{
    QString result = text;
    result.replace("\\", "\\\\");
    result.replace("'", "\\'");
    result.replace("\r", "\\r");
    result.replace("\n", "\\n");
    return result;
}

void MainWindow::insertCommand(const QString &command)
{
    const QString script = QString("mqCommand('%1');")
                               .arg(quoteForJavaScript(command));
    webView->page()->mainFrame()->evaluateJavaScript(script);
}

void MainWindow::getLatex()
{
    QVariant result = webView->page()->mainFrame()->evaluateJavaScript(
        "getLatex();");
    latexEdit->setText(result.toString());
    statusLabel->setText("LaTeX read from MathQuill.");
}

void MainWindow::setLatex()
{
    const QString script = QString("setLatex('%1');")
                               .arg(quoteForJavaScript(latexEdit->text()));
    webView->page()->mainFrame()->evaluateJavaScript(script);
    statusLabel->setText("Equation replaced from LaTeX.");
}

void MainWindow::clearEquation()
{
    webView->page()->mainFrame()->evaluateJavaScript("clearEquation();");
    latexEdit->clear();
    statusLabel->setText("Equation cleared.");
}

void MainWindow::copyLatex()
{
    getLatex();
    QApplication::clipboard()->setText(latexEdit->text());
    statusLabel->setText("LaTeX copied to the clipboard.");
}

void MainWindow::onLoadFinished(bool ok)
{
    if (!ok) {
        statusLabel->setText(
            "The editor page failed to load. Check Qt WebKit and network access.");
        return;
    }

    QVariant ready = webView->page()->mainFrame()->evaluateJavaScript(
        "if (!isMathQuillReady() && typeof initializeMathQuill === 'function') "
        "    initializeMathQuill(); "
        "isMathQuillReady();");

    if (ready.toBool()) {
        statusLabel->setText("MathQuill is ready.");
        setLatex();
    } else {
        statusLabel->setText(
            "The page loaded, but MathQuill did not. Check Internet/TLS access to cdnjs.");
    }
}
