#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>

class QLabel;
class QLineEdit;
class QPushButton;
class QSignalMapper;
class QWebView;

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void insertCommand(const QString &command);
    void getLatex();
    void setLatex();
    void clearEquation();
    void copyLatex();
    void onLoadFinished(bool ok);

private:
    QPushButton *makeCommandButton(const QString &caption,
                                   const QString &command,
                                   const QString &toolTip = QString());
    QString quoteForJavaScript(const QString &text) const;

    QWebView *webView;
    QLineEdit *latexEdit;
    QLabel *statusLabel;
    QSignalMapper *commandMapper;
};

#endif // MAINWINDOW_H
