# Qt 5.3 + MathQuill visual equation editor

A small Qt Widgets example showing an editable MathQuill equation field inside `QWebView`.

## What the sample demonstrates

- Qt 5.3 `QWebView` / Qt WebKit embedded in a normal Qt Widgets window.
- A visual editable equation field using MathQuill.
- Native Qt buttons for fraction, square root, powers, subscripts, integrals, sums, Greek letters, operators, etc.
- C++ -> JavaScript calls with `QWebFrame::evaluateJavaScript()`.
- JavaScript -> C++ data retrieval by returning the current LaTeX string.
- Get, set, copy, and clear the current equation.
- The HTML page is embedded into the executable with a `.qrc` resource file.

## Requirements

- Qt 5.3.x
- Qt Widgets
- Qt WebKit / Qt WebKit Widgets
- Network access when the editor starts, because this sample loads jQuery and MathQuill CSS/JS from cdnjs.

MathQuill 0.10.x requires jQuery. The page uses jQuery 1.11.3 and MathQuill 0.10.1-a.

## Build in Qt Creator

1. Extract/open this folder.
2. Open `Qt53MathQuillDemo.pro` in Qt Creator.
3. Select your Qt 5.3 kit.
4. Run qmake.
5. Build.
6. Run.

## Build from a Qt command prompt

```text
qmake Qt53MathQuillDemo.pro
make
```

On MinGW/Windows you may use `mingw32-make` instead of `make`.

## If qmake says WebKit is missing

If you see something similar to:

```text
Project ERROR: Unknown module(s) in QT: webkit webkitwidgets
```

then the selected Qt 5.3 installation/kit does not contain Qt WebKit. Install/use a Qt 5.3 kit that includes the WebKit modules.

## If the window opens but MathQuill does not appear

The sample's local `editor.html` uses HTTPS resources from cdnjs. Very old Qt/OpenSSL combinations can fail modern TLS negotiation.

Open the Qt application output and also look at the status message at the bottom of the window. If CDN/TLS loading is the problem, the next step is to keep `editor.html` local and host/download the MathQuill dependencies in a way your Qt 5.3 runtime can access.

## Important MathQuill limitation

MathQuill 0.10.1 handles common equation structures very well, including fractions, roots, scripts, integrals, sums, operators and symbols. Full LaTeX matrix environments such as `bmatrix` are not properly supported in this version, so this sample intentionally does not offer a matrix button.

## Files

```text
Qt53MathQuillDemo/
|-- Qt53MathQuillDemo.pro
|-- main.cpp
|-- mainwindow.h
|-- mainwindow.cpp
|-- resources.qrc
|-- web/
|   `-- editor.html
`-- README.md
```

## Main C++ / JavaScript bridge

Read the equation:

```cpp
QVariant result = webView->page()->mainFrame()->evaluateJavaScript(
    "getLatex();");
QString latex = result.toString();
```

Set the equation:

```cpp
webView->page()->mainFrame()->evaluateJavaScript(
    "setLatex('x^2+1');");
```

Insert a MathQuill command at the visual cursor:

```cpp
webView->page()->mainFrame()->evaluateJavaScript(
    "mqCommand('\\\\frac');");
```
